#!/usr/bin/env python3
"""Optional: receive leads as real webhooks.   python server.py  (port 8080)

    curl -X POST localhost:8080/lead -H 'content-type: application/json' \
         -d '{"id":"S-99","name":"Sam","email":"sam@x.com","company":"X","message":"..."}'

Same Pipeline.process() as main.py. A lock serialises requests because the sheet is a single file.
"""
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

from leadflow.llm import get_llm
from leadflow.pipeline import Pipeline

LOCK = threading.Lock()
PIPELINE = Pipeline("output", "data/existing_leads.csv", get_llm(os.getenv("LLM_PROVIDER", "stub")))


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/lead":
            return self._reply(404, {"error": "not found"})
        try:
            raw = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))))
            if not isinstance(raw, dict):
                raise ValueError("body must be a JSON object")
        except ValueError as exc:
            return self._reply(400, {"error": str(exc)})
        with LOCK:
            r = PIPELINE.process(raw)
        self._reply(200, {"id": r.submission_id, "outcome": r.outcome, "lead_id": r.lead_id, "tag": r.tag, "detail": r.detail})

    def _reply(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


if __name__ == "__main__":
    HTTPServer(("", 8080), Handler).serve_forever()
