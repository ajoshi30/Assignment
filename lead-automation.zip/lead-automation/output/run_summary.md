# Run summary

LLM: stub (rules-based, NOT an LLM)  |  notifications: file (notifications.log - stand-in for Slack)

Processed 15 submissions: 6 added, 4 duplicate, 4 needs_review, 1 rejected_spam

| Submission | Outcome | Lead | Tag | Detail |
|---|---|---|---|---|
| S-01 | added | L-1013 | Hot (notified) |  |
| S-02 | duplicate | L-1001 | Warm | existing_sheet L-1001 |
| S-03 | duplicate | L-1002 | Cold | existing_sheet L-1002 |
| S-04 | needs_review |  |  | no email address supplied |
| S-05 | needs_review |  |  | no email address supplied |
| S-06 | needs_review |  |  | invalid email address 'ben.carter@gmail' |
| S-07 | needs_review |  |  | invalid email address 'sara@@nordicform.se' |
| S-08 | added | L-1014 | Cold |  |
| S-09 | added | L-1015 | Hot (notified) |  |
| S-10 | added | L-1016 | Cold | prompt_injection_suspected; draft_replaced_by_guardrail |
| S-11 | rejected_spam |  |  | Unsolicited SEO/marketing pitch. |
| S-12 | added | L-1017 | Warm |  |
| S-13 | added | L-1018 | Cold | empty_message |
| S-14 | duplicate | L-1017 | Warm | earlier_submission L-1017 |
| S-15 | duplicate | L-1008 | Hot (notified) | existing_sheet L-1008 |
