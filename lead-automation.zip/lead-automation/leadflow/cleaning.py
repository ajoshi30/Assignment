"""Step 1: make incoming data consistent. Pure functions, no I/O, easy to test."""
import re
import unicodedata
from datetime import date, datetime

EMAIL_RE = re.compile(r"^[a-z0-9._%+\-]+@[a-z0-9\-]+(\.[a-z0-9\-]+)*\.[a-z]{2,}$")
PHONE_RE = re.compile(r"(?<!\w)\+?\d[\d \-()]{7,}\d(?!\w)")
COMPANY_SUFFIXES = {"ltd", "limited", "inc", "llc", "gmbh", "plc"}


def _s(value) -> str:
    """Coerce None / missing / non-str to a trimmed, NFC-normalised, single-spaced string."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFC", str(value)).strip()
    return re.sub(r"[ \t]+", " ", text)


def _fix_part(part: str) -> str:
    # Only re-case parts that are ALL CAPS or all lower; leave McDonald / van Berg-style casing alone.
    return part.capitalize() if part.isupper() or part.islower() else part


def clean_name(raw) -> str:
    """'  JAMES   o'CONNOR ' -> "James O'Connor". Unicode (Zoë Müller) is preserved."""
    out = []
    for token in _s(raw).split(" "):
        out.append(re.sub(r"[^'’\-]+", lambda m: _fix_part(m.group(0)), token))
    return " ".join(out)


def clean_company(raw) -> str:
    return _s(raw)


def clean_message(raw) -> str:
    return re.sub(r"\s+", " ", _s(raw))


def clean_email(raw):
    """Returns (email, problem). problem is None, 'missing' or 'invalid_format'."""
    email = _s(raw).lower()
    if email.startswith("mailto:"):
        email = email[7:]
    if not email:
        return "", "missing"
    if not EMAIL_RE.match(email):
        return email, "invalid_format"
    return email, None


def suggest_email_fix(raw) -> str:
    """Only suggest fixes that are unambiguous (e.g. a doubled '@'). Never guess a missing TLD."""
    fixed = re.sub(r"@{2,}", "@", _s(raw).lower())
    return fixed if fixed != _s(raw).lower() and EMAIL_RE.match(fixed) else ""


def email_key(email: str) -> str:
    """Dedupe key: lowercase, with any '+tag' removed from the local part (tom+x@a.com == tom@a.com)."""
    local, _, domain = email.lower().partition("@")
    return f"{local.split('+')[0]}@{domain}"


def company_key(company: str) -> str:
    """'Fern & Fox' and 'Fern and Fox' share a key."""
    text = company.lower().replace("&", " and ")
    tokens = re.sub(r"[^\w\s]", "", text).split()
    while len(tokens) > 1 and tokens[-1] in COMPANY_SUFFIXES:
        tokens.pop()
    return " ".join(tokens)


def name_company_key(name: str, company: str) -> str:
    return f"{name.lower()}|{company_key(company)}"


def extract_phone(message: str) -> str:
    m = PHONE_RE.search(message or "")
    return m.group(0).strip() if m else ""


def parse_date(raw) -> str:
    """'2026-10-11 13:32' -> '2026-10-11' (the sheet stores dates only). Falls back to today."""
    try:
        return datetime.fromisoformat(_s(raw)[:16].replace(" ", "T")).date().isoformat()
    except ValueError:
        return date.today().isoformat()
