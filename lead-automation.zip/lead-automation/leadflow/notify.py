"""Step 5: notify on Hot leads.

If SLACK_WEBHOOK_URL is set, posts to Slack. Otherwise appends to notifications.log
(a clearly labelled stand-in so the demo needs no accounts). Failures raise, and the
pipeline records them - a failed notification never loses the lead.
"""
import json
import os
import time
import urllib.request

from .store import now


class Notifier:
    def __init__(self, log_path: str, attempts: int = 3, base_delay: float = 1.0):
        self.log_path = log_path
        self.webhook = os.getenv("SLACK_WEBHOOK_URL", "")
        self.attempts, self.base_delay = attempts, base_delay
        self.channel = "slack" if self.webhook else "file (notifications.log - stand-in for Slack)"

    def send(self, text: str):
        if not self.webhook:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(f"[{now()}] {text}\n{'-' * 60}\n")
            return
        last = None
        for i in range(self.attempts):
            try:
                req = urllib.request.Request(
                    self.webhook, json.dumps({"text": text}).encode(),
                    {"content-type": "application/json"}, method="POST")
                urllib.request.urlopen(req, timeout=10).read()
                return
            except Exception as exc:
                last = exc
                if i < self.attempts - 1:
                    time.sleep(self.base_delay * 2**i)
        raise RuntimeError(f"Slack notification failed: {last}")
