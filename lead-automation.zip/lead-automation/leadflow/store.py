"""The 'Google Sheet': leads.csv, plus two side files that make problems visible.

  leads.csv        the leads sheet (existing 12 rows + new ones). Extra columns are appended.
  duplicates.csv   every submission recognised as a duplicate, and which lead it matched.
  exceptions.csv   everything that was NOT added cleanly: needs_review, rejected_spam,
                   llm_error, flagged_added (prompt injection), notification_failed, unexpected_error.

Writes are atomic (temp file + rename) so a crash never leaves a half-written sheet.
"""
import csv
import os
import tempfile
from datetime import datetime

from .cleaning import email_key, name_company_key

BASE_FIELDS = ["lead_id", "name", "email", "company", "source", "tag", "created_at"]
EXTRA_FIELDS = ["phone", "message", "draft_reply", "flags", "notes", "submission_id", "notified"]
LEAD_FIELDS = BASE_FIELDS + EXTRA_FIELDS
DUP_FIELDS = ["logged_at", "submission_id", "matched_lead_id", "match_type", "name", "email", "company",
              "message", "tag", "draft_reply", "action"]
EXC_FIELDS = ["logged_at", "submission_id", "outcome", "reason", "name", "email_raw", "company",
              "message", "phone", "suggested_fix"]


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _read(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _atomic_write(path, fields, rows):
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or ".", suffix=".tmp")
    with os.fdopen(fd, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    os.replace(tmp, path)


class AppendLog:
    """Append-only CSV with a fixed header (duplicates.csv, exceptions.csv)."""

    def __init__(self, path, fields):
        self.path, self.fields = path, fields

    def rows(self):
        return _read(self.path)

    def add(self, **row):
        new = not os.path.exists(self.path)
        with open(self.path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=self.fields, extrasaction="ignore")
            if new:
                w.writeheader()
            w.writerow({"logged_at": now(), **row})


class Sheet:
    def __init__(self, path):
        self.path = path
        self.rows = [{k: r.get(k, "") for k in LEAD_FIELDS} for r in _read(path)]
        self._reindex()

    def _reindex(self):
        self.by_email = {}
        self.by_name_company = {}
        for r in self.rows:
            if r["email"]:
                self.by_email.setdefault(email_key(r["email"]), r)
            self.by_name_company.setdefault(name_company_key(r["name"], r["company"]), r)

    def next_id(self) -> str:
        nums = [int(r["lead_id"].split("-")[1]) for r in self.rows if r["lead_id"].startswith("L-")]
        return f"L-{max(nums, default=1000) + 1}"

    def add(self, row: dict):
        self.rows.append({k: row.get(k, "") for k in LEAD_FIELDS})
        self._reindex()
        self.save()

    def append_note(self, lead_id: str, note: str):
        for r in self.rows:
            if r["lead_id"] == lead_id:
                r["notes"] = (r["notes"] + " | " if r["notes"] else "") + note
        self.save()

    def save(self):
        _atomic_write(self.path, LEAD_FIELDS, self.rows)
