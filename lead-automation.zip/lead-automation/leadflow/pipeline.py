"""process(raw_lead) is the whole workflow for ONE lead - i.e. one webhook delivery."""
import logging
import os
import shutil
import uuid
from dataclasses import dataclass

from . import cleaning as c
from .llm import detect_injection, draft_problem, safe_draft
from .notify import Notifier
from .store import DUP_FIELDS, EXC_FIELDS, AppendLog, Sheet

log = logging.getLogger("leadflow")


@dataclass
class Result:
    submission_id: str
    outcome: str  # added | duplicate | needs_review | rejected_spam | llm_error | skipped | error
    detail: str = ""
    lead_id: str = ""
    tag: str = ""
    notified: bool = False


class Pipeline:
    def __init__(self, out_dir: str, seed_csv: str, llm, notifier: Notifier = None):
        os.makedirs(out_dir, exist_ok=True)
        sheet_path = os.path.join(out_dir, "leads.csv")
        if not os.path.exists(sheet_path):
            shutil.copy(seed_csv, sheet_path)  # the input file is never modified
        self.sheet = Sheet(sheet_path)
        self.dups = AppendLog(os.path.join(out_dir, "duplicates.csv"), DUP_FIELDS)
        self.exceptions = AppendLog(os.path.join(out_dir, "exceptions.csv"), EXC_FIELDS)
        self.llm = llm
        self.notifier = notifier or Notifier(os.path.join(out_dir, "notifications.log"))
        # Idempotency: a submission id we've already handled (in any outcome) is skipped on re-run.
        self.seen = {r["submission_id"] for r in self.sheet.rows if r["submission_id"]}
        self.seen |= {r["submission_id"] for r in self.dups.rows()}
        self.seen |= {r["submission_id"] for r in self.exceptions.rows()}

    # ------------------------------------------------------------------ public entry point
    def process(self, raw: dict) -> Result:
        sid = str(raw.get("id") or f"anon-{uuid.uuid4().hex[:8]}")
        if sid in self.seen:
            return Result(sid, "skipped", "already processed")
        try:
            result = self._process(sid, raw)
        except Exception as exc:  # last resort: nothing may vanish silently
            log.exception("unexpected error on %s", sid)
            self._exception(sid, "unexpected_error", f"{type(exc).__name__}: {exc}", raw=raw)
            result = Result(sid, "error", str(exc))
        self.seen.add(sid)
        return result

    # ------------------------------------------------------------------ the workflow
    def _process(self, sid, raw) -> Result:
        # 1. CLEAN
        name = c.clean_name(raw.get("name"))
        company = c.clean_company(raw.get("company"))
        message = c.clean_message(raw.get("message"))
        phone = c.extract_phone(message)
        email, problem = c.clean_email(raw.get("email"))
        created = c.parse_date(raw.get("received_at"))
        lead = {"name": name, "email": email, "company": company, "message": message}

        if problem:
            reason = ("no email address supplied" if problem == "missing"
                      else f"invalid email address {raw.get('email')!r}")
            self._exception(sid, "needs_review", reason, raw=raw, name=name, company=company,
                            message=message, phone=phone,
                            suggested_fix=c.suggest_email_fix(raw.get("email")))
            return Result(sid, "needs_review", reason)

        # 3 (first half). LLM - done before the dup branch so re-engagement on a known lead is not missed
        injection = detect_injection(message)
        try:
            cls = self.llm.classify(lead)
        except Exception as exc:
            reason = f"classification failed: {exc}"
            self._exception(sid, "llm_error", reason, raw=raw, name=name, company=company, message=message)
            return Result(sid, "llm_error", reason)
        injection = injection or cls.injection_suspected
        tag = "Cold" if injection else cls.tag  # an injection attempt can never raise a lead's priority

        # 2. DEDUPE (existing sheet + earlier submissions in this batch share one index)
        match = self.sheet.by_email.get(c.email_key(email))
        if match:
            return self._handle_duplicate(sid, match, lead, tag, cls, created)

        # spam is rejected visibly, not silently dropped
        if cls.is_spam:
            self._exception(sid, "rejected_spam", cls.reasoning or "classified as spam", raw=raw,
                            name=name, company=company, message=message)
            return Result(sid, "rejected_spam", cls.reasoning)

        flags = []
        possible = self.sheet.by_name_company.get(c.name_company_key(name, company))
        if possible:
            flags.append(f"possible_duplicate_of:{possible['lead_id']}")
        if injection:
            flags.append("prompt_injection_suspected")
        if not message:
            flags.append("empty_message")

        draft = cls.draft_reply
        problem_draft = draft_problem(draft)
        if injection or problem_draft:  # never ship model text that was influenced by an attack
            draft = safe_draft(name, company, tag, cls.language)
            flags.append("draft_replaced_by_guardrail")
            if problem_draft:
                flags.append(f"guardrail:{problem_draft}")

        # 4. ADD TO SHEET
        lead_id = self.sheet.next_id()
        self.sheet.add({
            "lead_id": lead_id, "name": name, "email": email, "company": company, "source": "website",
            "tag": tag, "created_at": created, "phone": phone, "message": message,
            "draft_reply": draft, "flags": ";".join(flags), "submission_id": sid,
            "notes": cls.reasoning,
        })

        # 5. NOTIFY (Hot only)
        notified = False
        if tag == "Hot":
            notified = self._notify(
                f":fire: HOT lead {lead_id}: {name} ({company or 'no company'}) <{email}>\n"
                f"Why: {cls.reasoning}\nMessage: {message}\n\nDraft reply:\n{draft}",
                sid, lead_id)
            self.sheet.rows[-1]["notified"] = "yes" if notified else "FAILED"
            if not notified:
                self.sheet.rows[-1]["flags"] = ";".join(flags + ["notification_failed"])
            self.sheet.save()

        # 6. VISIBILITY for anything unusual that was still added
        if injection:
            self._exception(sid, "flagged_added", "possible prompt injection in message; forced to Cold, "
                            "draft replaced with safe template", raw=raw, name=name, company=company, message=message)
        return Result(sid, "added", "; ".join(flags), lead_id, tag, notified)

    # ------------------------------------------------------------------ helpers
    def _handle_duplicate(self, sid, match, lead, tag, cls, created) -> Result:
        match_type = "earlier_submission" if match["submission_id"] else "existing_sheet"
        draft = cls.draft_reply if not draft_problem(cls.draft_reply) else ""
        action = "logged"
        if lead["message"]:  # keep the new context on the original lead; never overwrite its tag
            self.sheet.append_note(match["lead_id"], f"[{sid} {created}] {lead['message'][:300]}")
            action = "note added to original lead"
        notified = False
        if tag == "Hot":
            note = ("" if match["tag"] == "Hot" else f" Current tag is {match['tag']} - consider upgrading.")
            notified = self._notify(
                f":repeat: Existing lead {match['lead_id']} ({match['name']}, {match['company']}) came back "
                f"with HOT intent.{note}\nMessage: {lead['message']}\n\nDraft reply:\n{draft}",
                sid, match["lead_id"])
            action += "; Hot re-engagement notified" if notified else "; Hot re-engagement NOTIFICATION FAILED"
        self.dups.add(submission_id=sid, matched_lead_id=match["lead_id"], match_type=match_type,
                      name=lead["name"], email=lead["email"], company=lead["company"],
                      message=lead["message"], tag=tag, draft_reply=draft, action=action)
        return Result(sid, "duplicate", f"{match_type} {match['lead_id']}", match["lead_id"], tag, notified)

    def _notify(self, text, sid, lead_id) -> bool:
        try:
            self.notifier.send(text)
            return True
        except Exception as exc:
            self._exception(sid, "notification_failed", str(exc), lead_id=lead_id)
            return False

    def _exception(self, sid, outcome, reason, raw=None, lead_id="", **fields):
        raw = raw or {}
        reason = f"{lead_id}: {reason}" if lead_id else reason
        self.exceptions.add(
            submission_id=sid, outcome=outcome, reason=reason, name=fields.get("name", raw.get("name", "")),
            email_raw=raw.get("email", ""), company=fields.get("company", raw.get("company", "")),
            message=fields.get("message", raw.get("message", "")), phone=fields.get("phone", ""),
            suggested_fix=fields.get("suggested_fix", ""))
