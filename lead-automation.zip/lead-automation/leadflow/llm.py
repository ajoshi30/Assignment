"""Step 3: classification + draft reply.

Providers
  stub       rules-based, offline, free. CLEARLY NOT AN LLM - it imitates the rubric in prompts.py
             so the whole pipeline can be demonstrated without an API key.
  anthropic  Anthropic Messages API   (env: ANTHROPIC_API_KEY, optional LLM_MODEL)
  openai     any OpenAI-compatible API, e.g. Groq / OpenRouter / Ollama
             (env: LLM_API_KEY, LLM_BASE_URL, LLM_MODEL)

Whatever the provider returns is treated as untrusted: it is validated against a schema, and
the draft reply goes through a guardrail before it is stored.
"""
import json
import os
import re
import time
import urllib.request
from dataclasses import dataclass

from .prompts import SYSTEM_PROMPT, build_user_prompt

TAGS = {"Hot", "Warm", "Cold"}


@dataclass
class Classification:
    tag: str
    is_spam: bool
    injection_suspected: bool
    language: str
    reasoning: str
    draft_reply: str


# ----------------------------------------------------------------------------- validation
def validate(data: dict) -> Classification:
    if not isinstance(data, dict):
        raise ValueError("LLM output is not a JSON object")
    tag = str(data.get("tag", "")).strip().capitalize()
    if tag not in TAGS:
        raise ValueError(f"invalid tag {data.get('tag')!r}")
    draft = data.get("draft_reply", "")
    if not isinstance(draft, str):
        raise ValueError("draft_reply must be a string")
    return Classification(
        tag=tag,
        is_spam=bool(data.get("is_spam", False)),
        injection_suspected=bool(data.get("injection_suspected", False)),
        language=str(data.get("language", "en"))[:5],
        reasoning=str(data.get("reasoning", ""))[:300],
        draft_reply=draft.strip(),
    )


def parse_json_loose(text: str) -> dict:
    """Models sometimes wrap JSON in prose or code fences; grab the outermost {...}."""
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end <= start:
        raise ValueError("no JSON object in LLM response")
    return json.loads(text[start : end + 1])


# ----------------------------------------------------------------------------- guardrails
INJECTION_RE = re.compile(
    r"ignore (all |any |your |the )?(previous|prior|above) (instructions|prompts?)"
    r"|disregard (all |your )?(previous|prior)"
    r"|system prompt|you are now|\bwhatever ai\b|mark this lead as"
    r"|\bAI\b.{0,30}\b(read|reads)s? this",
    re.I,
)


def detect_injection(message: str) -> bool:
    """Deterministic check that runs regardless of provider (defence in depth)."""
    return bool(INJECTION_RE.search(message or ""))


COMMITMENT_RE = re.compile(
    r"\d+\s?%|\bdiscount|\bfree of charge\b|\bguarantee|[£$€]\s?\d|\bwaive|\bno cost\b", re.I
)


def draft_problem(draft: str):
    """Drafts must never carry prices, discounts or promises. Returns a reason or None."""
    if not draft.strip():
        return "empty draft"
    if COMMITMENT_RE.search(draft):
        return "draft contains a price/discount/commitment"
    if len(draft.split()) > 160:
        return "draft too long"
    return None


# ----------------------------------------------------------------------------- templates
_TEMPLATES = {
    "en": {
        "Hot": "Hi {first},\n\nThanks for getting in touch - this sounds like a good fit and I'd like to move "
               "quickly on it. Are you free for a short call in the next day or two to confirm the details? "
               "Send me a couple of times that suit you and I'll send an invite.\n\nBest,\n[Your name]",
        "Warm": "Hi {first},\n\nThanks for reaching out about {company}. Before suggesting anything I'd like to "
                "understand what you're trying to achieve. Could you tell me a little about how this works today "
                "and what you'd most like to improve? Happy to set up a short call if that's easier.\n\nBest,\n[Your name]",
        "Cold": "Hi {first},\n\nThanks for your message. Whenever you're ready to explore this further, just reply "
                "and tell me a bit about what you have in mind - I'm happy to answer questions in the meantime."
                "\n\nBest,\n[Your name]",
    },
    "de": {
        "Hot": "Hallo {first},\n\nvielen Dank für Ihre Nachricht - das klingt nach einer guten Zusammenarbeit und ich "
               "würde gern zeitnah starten. Hätten Sie in den nächsten Tagen Zeit für ein kurzes Gespräch? Nennen Sie "
               "mir gern zwei, drei passende Termine, dann schicke ich eine Einladung.\n\nBeste Grüße\n[Your name]",
        "Warm": "Hallo {first},\n\nvielen Dank für Ihre Anfrage. Damit ich Ihnen sinnvoll helfen kann, würde ich gern "
                "mehr über Ihr Vorhaben erfahren. Wie läuft das aktuell bei {company}, und was möchten Sie verbessern?"
                "\n\nBeste Grüße\n[Your name]",
        "Cold": "Hallo {first},\n\nvielen Dank für Ihre Nachricht. Wenn Sie so weit sind, antworten Sie gern kurz mit "
                "Ihren Vorstellungen - ich beantworte bis dahin gern Fragen.\n\nBeste Grüße\n[Your name]",
    },
}


def safe_draft(name: str, company: str, tag: str, language: str = "en") -> str:
    lang = language if language in _TEMPLATES else "en"
    first = (name.split(" ")[0] if name else "there")
    return _TEMPLATES[lang][tag].format(first=first, company=company or "your business")


# ----------------------------------------------------------------------------- providers
class StubLLM:
    """Rules-based stand-in. Same interface and output schema as a real model."""

    name = "stub (rules-based, NOT an LLM)"

    SPAM = re.compile(r"guaranteed|backlinks?|rank #?1|\bseo\b|price list|crypto|casino|viagra|followers", re.I)
    GERMAN = re.compile(r"\b(wir|suchen|ist|vorhanden|und|unsere|jemanden|der|im)\b", re.I)
    SIGNALS = [  # (regex, weight, label)
        (r"budget|approved|vorhanden|[£$€]\s?\d", 2, "budget"),
        (r"go ahead|get going|get started|ready to (start|go|proceed)", 2, "go-ahead"),
        (r"\bproposal\b|\bquote to proceed\b", 2, "asks for proposal"),
        (r"this month|this week|asap|immediately|\bstart im\b|november|next week", 1, "near-term timing"),
        (r"automat|connect|integrat|booking|invoic|onboarding|reminders|webshop|lead[- ]?prozess", 1, "concrete need"),
        (r"we need|we'd like|we want|looking to|wir suchen", 1, "stated need"),
        (r"call|chat|keen|interested|\bquote\b", 1, "engagement"),
        (r"just researching|next quarter|exploring|not sure yet|someday", -2, "exploratory"),
    ]

    def classify(self, lead: dict) -> Classification:
        msg = lead.get("message", "") or ""
        lang = "de" if len(self.GERMAN.findall(msg)) >= 3 else "en"
        if self.SPAM.search(msg) and not lead.get("company"):
            return Classification("Cold", True, False, lang, "Unsolicited SEO/marketing pitch.", "")
        score, hits = 0, []
        for pattern, weight, label in self.SIGNALS:
            if re.search(pattern, msg, re.I):
                score += weight
                hits.append(label)
        tag = "Hot" if score >= 4 else "Warm" if score >= 1 else "Cold"
        reasoning = f"[stub] score {score} from: {', '.join(hits) or 'no buying signals / empty message'}."
        draft = safe_draft(lead.get("name", ""), lead.get("company", ""), tag, lang)
        return Classification(tag, False, detect_injection(msg), lang, reasoning, draft)


def _post_json(url: str, headers: dict, body: dict, timeout: int = 30) -> dict:
    req = urllib.request.Request(url, json.dumps(body).encode(), headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


class AnthropicLLM:
    name = "anthropic"

    def __init__(self):
        self.key = os.environ["ANTHROPIC_API_KEY"]
        self.model = os.getenv("LLM_MODEL", "claude-haiku-5-5")

    def classify(self, lead: dict) -> Classification:
        data = _post_json(
            "https://api.anthropic.com/v1/messages",
            {"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            {"model": self.model, "max_tokens": 700, "system": SYSTEM_PROMPT,
             "messages": [{"role": "user", "content": build_user_prompt(lead)}]},
        )
        return validate(parse_json_loose(data["content"][0]["text"]))


class OpenAICompatLLM:
    name = "openai-compatible"

    def __init__(self):
        self.key = os.getenv("LLM_API_KEY", "")
        self.base = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        self.model = os.environ["LLM_MODEL"]

    def classify(self, lead: dict) -> Classification:
        headers = {"content-type": "application/json"}
        if self.key:
            headers["authorization"] = f"Bearer {self.key}"
        data = _post_json(
            f"{self.base}/chat/completions", headers,
            {"model": self.model, "temperature": 0,
             "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                          {"role": "user", "content": build_user_prompt(lead)}]},
        )
        return validate(parse_json_loose(data["choices"][0]["message"]["content"]))


class Retrying:
    """Wraps any provider: retries transient failures and malformed output with exponential backoff."""

    def __init__(self, inner, attempts: int = 3, base_delay: float = 1.0):
        self.inner, self.attempts, self.base_delay = inner, attempts, base_delay
        self.name = inner.name

    def classify(self, lead: dict) -> Classification:
        last = None
        for i in range(self.attempts):
            try:
                return self.inner.classify(lead)
            except Exception as exc:  # network, HTTP, bad JSON, schema - all retryable here
                last = exc
                if i < self.attempts - 1:
                    time.sleep(self.base_delay * 2**i)
        raise RuntimeError(f"LLM failed after {self.attempts} attempts: {last}") from last


def get_llm(provider: str):
    providers = {"stub": StubLLM, "anthropic": AnthropicLLM, "openai": OpenAICompatLLM}
    if provider not in providers:
        raise SystemExit(f"unknown provider {provider!r}; choose from {sorted(providers)}")
    llm = providers[provider]()
    return llm if provider == "stub" else Retrying(llm)
