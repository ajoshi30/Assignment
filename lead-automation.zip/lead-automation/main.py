#!/usr/bin/env python3
"""Replay incoming_leads.json as if each lead were a webhook delivery.

    python main.py                       # stub LLM, outputs in ./output
    python main.py --provider anthropic  # real LLM (needs ANTHROPIC_API_KEY)
    python main.py --reset               # wipe ./output first
    python main.py --delay 0.5           # pause between leads to mimic live traffic
"""
import argparse
import json
import logging
import os
import shutil
import sys
import time

from leadflow.llm import get_llm
from leadflow.pipeline import Pipeline


def write_summary(out_dir, results, pipeline, llm_name):
    counts = {}
    for r in results:
        counts[r.outcome] = counts.get(r.outcome, 0) + 1
    lines = [f"# Run summary\n", f"LLM: {llm_name}  |  notifications: {pipeline.notifier.channel}\n",
             f"Processed {len(results)} submissions: " + ", ".join(f"{v} {k}" for k, v in sorted(counts.items())) + "\n",
             "| Submission | Outcome | Lead | Tag | Detail |", "|---|---|---|---|---|"]
    for r in results:
        lines.append(f"| {r.submission_id} | {r.outcome} | {r.lead_id} | {r.tag}{' (notified)' if r.notified else ''} | {r.detail} |")
    with open(os.path.join(out_dir, "run_summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--leads", default="data/incoming_leads.json")
    ap.add_argument("--seed", default="data/existing_leads.csv")
    ap.add_argument("--out", default="output")
    ap.add_argument("--provider", default=os.getenv("LLM_PROVIDER", "stub"), choices=["stub", "anthropic", "openai"])
    ap.add_argument("--reset", action="store_true", help="delete the output directory first")
    ap.add_argument("--delay", type=float, default=0.0)
    args = ap.parse_args()

    if args.reset and os.path.isdir(args.out):
        shutil.rmtree(args.out)
    os.makedirs(args.out, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout),
                                  logging.FileHandler(os.path.join(args.out, "run.log"), encoding="utf-8")])

    llm = get_llm(args.provider)
    pipeline = Pipeline(args.out, args.seed, llm)
    with open(args.leads, encoding="utf-8") as f:
        leads = json.load(f)

    results = []
    for raw in leads:
        r = pipeline.process(raw)
        results.append(r)
        logging.info("%-5s -> %-13s %s %s %s", r.submission_id, r.outcome, r.lead_id, r.tag, r.detail)
        time.sleep(args.delay)
    write_summary(args.out, results, pipeline, llm.name)
    logging.info("done. see %s/run_summary.md, exceptions.csv, duplicates.csv", args.out)


if __name__ == "__main__":
    main()
